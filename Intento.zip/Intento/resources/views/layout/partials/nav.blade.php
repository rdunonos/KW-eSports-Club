<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top" id="menu">
      <div class="container">
        
        <img src="img/kwesportsclub.png" height="55" />
        <!--<a class="navbar-brand" href="index.html"> KW eSports</a>-->

        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive" >
          <ul class="navbar-nav ml-auto" id="items">
            <li class="nav-item">
              <a class="nav-link" href="intento" id="iMenu">Inicio</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Nosotros
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" id="navbarDropdownOpciones">
                <a class="dropdown-item" href="historia" id="iMenu">Historia</a>
                <a class="dropdown-item" href="galeria" id="iMenu">Galeria</a>
                
              </div>
            </li>
                      
            <li class="nav-item">
              <a class="nav-link" href="calendario" id="iMenu">
                Calendario
              </a>
              
            </li>



            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Equipos
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" id="navbarDropdownOpciones">
                <a class="dropdown-item" href="lol" id="iMenu">League of Legends</a>
                <a class="dropdown-item" href="pubg" id="iMenu">PUBG</a>
                <a class="dropdown-item" href="aov" id="iMenu">Arena of Valor</a>
                <a class="dropdown-item" href="hs" id="iMenu">Hearthstone</a>
                
              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="blog" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Blog</a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" id="navbarDropdownOpciones">
                <a class="dropdown-item" href="eventos" id="iMenu">Eventos</a>
                <a class="dropdown-item" href="partidos" id="iMenu">Partidos</a>
                
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contacto" id="iMenu">Contacto</a>
            </li>
            
          </ul>
        </div>
      </div>
    </nav>
 
 
  