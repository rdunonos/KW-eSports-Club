

    <div class="container">
    <div class="row">
          <div class="col-md-2"> </div>
          <div class="col-md-8">
            <h1>Contáctanos</h1>
            <p class="lead">¿Tienes una pregunta o necesitas más información?</p>

            <p>Llena el formulario y nos pondremos en contacto contigo lo antes posible.</p> <br>

            <!-- BEGIN DOWNLOAD PANEL -->
            <div class="panel panel-default well">
              <div class="panel-body">
                <form action="/" class="form-horizontal track-event-form bv-form" data-goaltype="”General”" role="form" data-formname="”ContactUs”" method="post"  novalidate="novalidate">
                    {{ csrf_field() }}
                  <input name="elqSiteId" type="hidden" value="928">
                  <input name="sFDCLastCampaignID" type="hidden" value="701400000012Lql">
                  <input name="elqFormName" type="hidden" value="EMEAAllContactUsSubmissions">
                  <input name="nexturl" type="hidden" value="">
                  <input name="Partner" type="hidden" value="">
                  <input name="language" type="hidden" value="en">

                  <div class="form-group">
                    <div class="col-sm-6">
                      <div class="input-group">
                        <div class="input-group-addon">
                          <i class="fa fa-user"></i>
                        </div>
                        <input type="text" class="form-control"  placeholder="Nombre(s)" name="name" data-bv-field="C_FirstName">
                      </div>
                        <small data-bv-validator="notEmpty" data-bv-validator-for="C_FirstName" class="help-block" style="display: none;">Required</small>
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="col-sm-6">
                      <div class="input-group">
                        <div class="input-group-addon">
                              <i class="fa fa-envelope"></i>
                        </div>
                            <input type="text" class="form-control"  placeholder="Ingresa email" name="email" data-bv-field="C_EmailAddress">
                      </div>
                            <small data-bv-validator="notEmpty" data-bv-validator-for="C_EmailAddress" class="help-block" style="display: none;">Required</small>
                    </div>
                  </div>


                            <div class="col-sm-6">
                              <div class="input-group" style="display: none;">
                        <div class="input-group-addon">
                          <i class="fa fa-globe"></i>
                                  </div>
                      </div>
                            </div>


                          <div class="form-group">
                    <div class="col-sm-12">
                      <div class="input-group">
                        <input type="hidden" class="form-control" id="C_BusPhone" placeholder="Teléfono" name="C_BusPhone">
                      </div>
                    </div>
                          </div>

                          <div class="form-group">
                            <div class="col-sm-12">
                      <div class="input-group">
                        <div class="input-group-addon">
                          <i class="fa fa-comment fa-2"></i>
                        </div>
                        <textarea class="form-control" name="body"  rows="5" style="width:99.9%" placeholder="Ingresa tu mensaje"></textarea>
                      </div>
                    </div>
                          </div>

                          <div class="form-group">
                            <div class="col-sm-12">
                      <button id="contacts-submit" type="submit" class="btn btn-default btn-info">CONTACTANOS</button>
                            </div>
                          </div>
                <input type="hidden" value="">
              </form>
              </div><!-- end panel-body -->
            </div><!-- end panel -->
            <!-- END DOWNLOAD PANEL -->
          </div><!-- end col-md-8 -->
          <div class="col-md-2"> </div>
            </div>
    </div>
