
@extends('layout.mainlayout')
<!DOCTYPE html>
<html>
<head>
	<title>
		Hearthstone
	</title>
	<!-- Bootstrap core CSS -->
    <link href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="{{asset('css/modern-business.css')}}" rel="stylesheet">
</head>
<body>

  @include('layout.partials.team')
 

</body>
</html>