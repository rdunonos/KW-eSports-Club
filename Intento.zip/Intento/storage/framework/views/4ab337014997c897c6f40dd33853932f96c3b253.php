<!DOCTYPE html>
<html>
<head>
	<title>
		Contacto
	</title>
	<!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/modern-business.css')); ?>" rel="stylesheet">
		<style media="screen">
		@import  url("http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,700italic,400,300,700");
		@import  url("http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600|Roboto Mono");
		@import  url("https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css");
		@font-face {
		font-family: 'Dosis';
		font-style: normal;
		font-weight: 300;
		src: local('Dosis Light'), local('Dosis-Light'), url(http://fonts.gstatic.com/l/font?kit=RoNoOKoxvxVq4Mi9I4xIReCW9eLPAnScftSvRB4WBxg&skey=a88ea9d907460694) format('woff2');
		}
		@font-face {
		font-family: 'Dosis';
		font-style: normal;
		font-weight: 500;
		src: local('Dosis Medium'), local('Dosis-Medium'), url(http://fonts.gstatic.com/l/font?kit=Z1ETVwepOmEGkbaFPefd_-CW9eLPAnScftSvRB4WBxg&skey=21884fc543bb1165) format('woff2');
		}
		body {

		  font-family: 'Source Sans Pro', 'Helvetica Neue', Arial, sans-serif,  Open Sans;
		  font-size: 14px;
		  line-height: 1.42857;
		  height: 350px;
		  padding: 0;
		  margin: 0;
		}
		</style>
</head>
<body>

  <!--incluimos formulario-->
	 <?php echo $__env->make('layout.partials.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>

<?php echo $__env->make('layout.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>