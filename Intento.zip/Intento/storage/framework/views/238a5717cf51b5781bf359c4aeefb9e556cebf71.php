<!DOCTYPE html>
<html>
<head>
	<title>
		Playerunknown's Battlegrounds
	</title>
	<!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/modern-business.css')); ?>" rel="stylesheet">
</head>
<body>

  <?php echo $__env->make('layout.partials.team', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
<?php echo $__env->make('layout.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>