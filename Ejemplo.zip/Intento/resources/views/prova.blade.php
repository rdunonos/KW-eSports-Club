<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href= {{'asset/css/app.css'}} rel="stylesheet">
        <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
 
        <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="collapse bg-inverse" id="navbarHeader">
 
     <div class="container">
 
       <div class="row">
 
         <div class="col-sm-8 py-4">
 
           <h4 class="text-white">About</h4>
 
           <p class="text-muted">Add some information about the album below, the author, or any other background context. Make it a few sentences long so folks can pick up some informative tidbits. Then, link them off to some social networking sites or contact information.</p>
 
         </div>
 
         <div class="col-sm-4 py-4">
 
           <h4 class="text-white">Contact</h4>
 
           <ul class="list-unstyled">
 
             <li><a href="#" class="text-white">Follow on Twitter</a></li>
 
             <li><a href="#" class="text-white">Like on Facebook</a></li>
 
             <li><a href="#" class="text-white">Email me</a></li>
 
           </ul>
 
         </div>
 
       </div>
 
     </div>
 
   </div>
 
   <div class="navbar navbar-inverse bg-inverse">
 
     <div class="container d-flex justify-content-betIen">
 
       <a href="#" class="navbar-brand">Album</a>
 
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
 
         <span class="navbar-toggler-icon"></span>
 
       </button>
 
     </div>
 
   </div>
 
 
 
   <div class="collapse bg-inverse" id="navbarHeader">
 
     <div class="container">
 
       <div class="row">
 
         <div class="col-sm-8 py-4">
 
           <h4 class="text-white">About</h4>
 
           <p class="text-muted">Add some information about the album below, the author, or any other background context. Make it a few sentences long so folks can pick up some informative tidbits. Then, link them off to some social networking sites or contact information.</p>
 
         </div>
 
         <div class="col-sm-4 py-4">
 
           <h4 class="text-white">Contact</h4>
 
           <ul class="list-unstyled">
 
             <li><a href="#" class="text-white">Follow on Twitter</a></li>
 
             <li><a href="#" class="text-white">Like on Facebook</a></li>
 
             <li><a href="#" class="text-white">Email me</a></li>
 
           </ul>
 
         </div>
 
       </div>
 
     </div>
 
   </div>
 
   <div class="navbar navbar-inverse bg-inverse">
 
     <div class="container d-flex justify-content-betIen">
 
       <a href="#" class="navbar-brand">Album</a>
 
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
 
         <span class="navbar-toggler-icon"></span>
 
       </button>
 
     </div>
 
   </div>
    </body>
</html>
