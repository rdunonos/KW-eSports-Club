<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top" id="menu">
      <div class="container">
        <div class="logo" alt="logo" >
          <a href="<?php echo e(asset('inicio')); ?>"><img src="img/kwesportsclub.png" height="55" />
        </div>
        <!--<a class="navbar-brand" href="index.html"> KW eSports</a>-->

        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive" >
          <ul class="navbar-nav ml-auto" id="items" style=" text-transform: uppercase !important;">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(asset('inicio')); ?>" id="iMenu"><?php echo e(trans('navbar.inicio')); ?></a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php echo e(trans('navbar.nosotros')); ?>

              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" id="navbarDropdownOpciones">
                <a class="dropdown-item" href="<?php echo e(asset('historia')); ?>" id="iMenu"><?php echo e(trans('navbar.historia')); ?></a>
                <a class="dropdown-item" href="<?php echo e(asset('galeria')); ?>" id="iMenu"><?php echo e(trans('navbar.galeria')); ?></a>

              </div>
            </li>

            



            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle"  id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php echo e(trans('navbar.equipos')); ?>

              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" id="navbarDropdownOpciones">
                <a class="dropdown-item" href="<?php echo e(asset('lol')); ?>" id="iMenu">League of Legends</a>
                <a class="dropdown-item" href="<?php echo e(asset('pubg')); ?>" id="iMenu">PUBG</a>
                <a class="dropdown-item" href="<?php echo e(asset('aov')); ?>" id="iMenu">Arena of Valor</a>
                <a class="dropdown-item" href="<?php echo e(asset('hs')); ?>" id="iMenu">Hearthstone</a>

              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(trans('navbar.blog')); ?></a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" id="navbarDropdownOpciones">
                <a class="dropdown-item" href="postse" id="iMenu"><?php echo e(trans('navbar.eventos')); ?></a>
                <a class="dropdown-item" href="posts" id="iMenu"><?php echo e(trans('navbar.partidos')); ?></a>

              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(asset('contacto')); ?>" id="iMenu"><?php echo e(trans('navbar.contacto')); ?></a>
            </li>
            <li class="nav-item">
              
              <li><a href="<?php echo e(url('lang', ['en'])); ?>">En</a></li>
              <li><a href="<?php echo e(url('lang', ['es'])); ?>">Es</a></li>
              <li><a href="<?php echo e(url('lang', ['ca'])); ?>">Ca</a></li>
            </li>

          </ul>
        </div>
      </div>
    </nav>
