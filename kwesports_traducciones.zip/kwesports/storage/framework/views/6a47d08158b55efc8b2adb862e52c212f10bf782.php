  <div class="container">
    <div class="row">
        <div class="col-md-8">
          <h1><?php echo e($post->title); ?></h1>
            <img src="<?php echo e(asset('images/'.$post->image)); ?>" height="400" width="700">
            <p class="lead"><?php echo $post->body; ?></p>
        </div>

        <div class="col-md-4">
            <div class="well">

              <dl class="dl-horizontal">
                <dt>Last Updated:</dt>
                <dd><?php echo e(date('M j, Y H:i',strtotime($post->updated_at))); ?></dd>
              </dl>
              <hr>
              <div class="row">
                <div class="col-sm-6">
                    <a href="<?php echo e(route('postse.edit',$post->id)); ?>" class="btn btn-primary btn-block">edit</a>
                </div>
                <div class="col-sm-6">
                      <?php echo Form::open(['method' => 'DELETE','route' => ['postse.destroy', $post->id],'style'=>'display:inline']); ?>

                      <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                      <?php echo Form::close(); ?>

                </div>
              </div>
            </div>
          </div>
        </div>

            <div class="pull-left">
                <a class="btn btn-primary" href="<?php echo e(route('posts.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
  </div>

<?php echo $__env->make('layout.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>