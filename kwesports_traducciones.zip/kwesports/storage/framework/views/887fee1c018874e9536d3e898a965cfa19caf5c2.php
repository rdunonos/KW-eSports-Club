
  <div class="contact1">
    <div class="container-contact1">
      <div class="contact1-pic js-tilt" data-tilt>
        <img src="img/img-01.png" alt="IMG">
      </div>

      <form action="<?php echo e(route('contacto.store')); ?>" class="contact1-form validate-form" onkeypress="" method="POST">
        <span class="contact1-form-title">
          <?php echo e(trans('contacto.title')); ?>

        </span>

        <div class="wrap-input1 validate-input" data-validate = "<?php echo e(trans('contacto.validarNombre')); ?>" >
          <input class="input1" type="text" name="name" id="name" placeholder="<?php echo e(trans('contacto.nombre')); ?>">
          <span class="shadow-input1"></span>
        </div>

        <div class="wrap-input1 validate-input" data-validate = "<?php echo e(trans('contacto.validarEmail')); ?>">
          <input class="input1" type="text" name="email" id="email" placeholder="<?php echo e(trans('contacto.email')); ?>">
          <span class="shadow-input1"></span>
        </div>


        <div class="wrap-input1 validate-input" data-validate = "<?php echo e(trans('contacto.validarMensaje')); ?>">
          <textarea class="input1" name="comments" id="comments" placeholder="<?php echo e(trans('contacto.mensaje')); ?>"></textarea>
          <span class="shadow-input1"></span>
        </div>
        <div>
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        </div>
        <div class="container-contact1-form-btn">
          <button class="contact1-form-btn" name="submit" value="submit">
            <span>
              <?php echo e(trans('contacto.enviar')); ?>

              <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
            </span>
          </button>
        </div>
      </form>
    </div>
  </div>
  <script src="js/main.js"></script>
