<!DOCTYPE html>
<html lang="en">
    
    <!-- <?php echo  trans('passwords.user', ['email' => 'user@example.com'])?>-->
    <div class="container">
      <div class="titol">
      <a href=""><img src="img/kwesportsclub.png" height="250"/></a>
      <h1>KW ESPORTS CLUB</h1> 
      <button type="button" id="button-principal" class="btn btn-primary active">
        <a href="https://twitter.com/KWeSportsClub?lang=es" target="_blank" style="color:black !important">
            <?php echo e(trans('home.twitter')); ?>

        </a>
      </button>
    </div>
    <!--llamamos a la plantilla slider-->
    <?php echo $__env->make('layout.partials.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      <h1 class="my-4"></h1>

      <!-- Marketing Icons Section -->
      <div class="row">
        <div class="col-lg-4 mb-4">
          <div class="card h-100">
            <h4 class="card-header"><?php echo e(trans('home.nosotros')); ?></h4>
            <div class="card-body">
              <p class="card-text"><?php echo e(trans('home.nosotros2')); ?></p>
            </div>
            <div class="card-footer">
              <a href="historia" class="btn btn-primary"><?php echo e(trans('home.mas')); ?></a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mb-4">
          <div class="card h-100">
            <h4 class="card-header"><?php echo e(trans('home.evento')); ?></h4>
            <div class="card-body">
              <p class="card-text"><?php echo e(trans('home.evento2')); ?></p>
            </div>
            <div class="card-footer">
              <a href="postse" class="btn btn-primary"><?php echo e(trans('home.mas')); ?></a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mb-4">
          <div class="card h-100">
            <h4 class="card-header"><?php echo e(trans('home.partido')); ?></h4>
            <div class="card-body">
              <p class="card-text"><?php echo e(trans('home.partido2')); ?></p>
            </div>
            <div class="card-footer">
              <a href="posts" class="btn btn-primary"><?php echo e(trans('home.mas')); ?></a>
            </div>
          </div>
        </div>
      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<!--
    Footer 
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2018</p>
      </div>

      /.container 

    </footer>

    Bootstrap core JavaScript 
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
-->
  </body>

</html>

<?php echo $__env->make('layout.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>