<!DOCTYPE html>
<html>
<head>
  <title>
    <?php echo e(trans('nosotros.titleGaleria')); ?>

  </title>
  <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/modern-business.css')); ?>" rel="stylesheet">
</head>
<body>
  <div class="container">

      <h1 class="my-4 text-center text-lg-left"><?php echo e(trans('nosotros.title2')); ?></h1>
      <h3 class="my-4 text-center text-lg-left">Gamergy 2017</h3>
      <div class="row text-center text-lg-left">

        <div class="col-lg-3 col-md-4 col-xs-6">
          <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="img/1.jpg" alt="">
          </a>
        </div>
        <div class="col-lg-3 col-md-4 col-xs-6">
          <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="img/Hakki.jpg" alt="">
          </a>
        </div>
        <div class="col-lg-3 col-md-4 col-xs-6">
          <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="img/Dade.jpg" alt="">
          </a>
        </div>
    </div>

    <h3 class="my-4 text-center text-lg-left">Gamergy 2018</h3>
    <div class="row text-center text-lg-left">

        <div class="col-lg-3 col-md-4 col-xs-6">
          <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="img/Sonike.jpg" alt="">
          </a>
        </div>
        <div class="col-lg-3 col-md-4 col-xs-6">
          <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="img/Monchu.jpg" alt="">
          </a>
        </div>
      </div>

    </div>
  <!--incluimos formulario-->

</body>
</html>
<?php echo $__env->make('layout.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>