<head>
  <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
</head>

<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <h1>{{ trans('blog.crear') }}</h1>
        <div class="form-group">
            <strong>{{ trans('blog.titulo') }}</strong>
            {{ Form::text('title', null, array('placeholder' => 'Title','class' => 'form-control')) }}
        </div>

        <div class="form-group">
            {{ Form::label('Image')}}
            {{ Form::file('image', null, array('placeholder' => 'Title','class' => 'form-control')) }}
        </div>

        <div class="form-group">
            <strong>{{ trans('blog.body') }}</strong>
            {{ Form::textarea('body', null, array('placeholder' => 'Body','class' => 'form-control','style'=>'height:150px')) }}
        </div>

    <div class="btn btn-success btn-lg btn-block">
            <button type="submit" class="btn btn-success">{{ trans('blog.submit') }}</button>
    </div>
</div>
</div>
