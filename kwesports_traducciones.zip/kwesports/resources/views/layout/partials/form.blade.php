
  <div class="contact1">
    <div class="container-contact1">
      <div class="contact1-pic js-tilt" data-tilt>
        <img src="img/img-01.png" alt="IMG">
      </div>

      <form action="{{ route('contacto.store')}}" class="contact1-form validate-form" onkeypress="" method="POST">
        <span class="contact1-form-title">
          {{ trans('contacto.title') }}
        </span>

        <div class="wrap-input1 validate-input" data-validate = "{{ trans('contacto.validarNombre') }}" >
          <input class="input1" type="text" name="name" id="name" placeholder="{{ trans('contacto.nombre') }}">
          <span class="shadow-input1"></span>
        </div>

        <div class="wrap-input1 validate-input" data-validate = "{{ trans('contacto.validarEmail') }}">
          <input class="input1" type="text" name="email" id="email" placeholder="{{ trans('contacto.email') }}">
          <span class="shadow-input1"></span>
        </div>


        <div class="wrap-input1 validate-input" data-validate = "{{ trans('contacto.validarMensaje') }}">
          <textarea class="input1" name="comments" id="comments" placeholder="{{ trans('contacto.mensaje') }}"></textarea>
          <span class="shadow-input1"></span>
        </div>
        <div>
          <input type="hidden" name="_token" value="{{csrf_token()}}">
        </div>
        <div class="container-contact1-form-btn">
          <button class="contact1-form-btn" name="submit" value="submit">
            <span>
              {{ trans('contacto.enviar') }}
              <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
            </span>
          </button>
        </div>
      </form>
    </div>
  </div>
  <script src="js/main.js"></script>
