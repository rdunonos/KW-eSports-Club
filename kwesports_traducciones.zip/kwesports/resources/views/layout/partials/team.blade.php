<div class="container">

      <!-- Introduction Row -->
      <h1 class="my-4"></h1>

      <h3 class="my-4">Competiciones
        <small>activas</small>
      </h3>
      <ul>
      <li>
        <p></p>
      </li>
      <li>
        <p></p>
      </li>
      </ul>

      <!-- Team Members Row -->
      <div class="row">
        <div class="col-lg-12">
          <h2 class="my-4">Nuestro Equipo</h2>
        </div>
        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <img class="rounded-circle img-fluid d-block mx-auto" src="http://placehold.it/200x200" alt="">
          <h3>
            <small>Jugador</small>
          </h3>
          <p></p>
        </div>
        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <img class="rounded-circle img-fluid d-block mx-auto" src="http://placehold.it/200x200" alt="">
          <h3>
            <small>Jugador</small>
          </h3>
          <p></p>
        </div>
        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <img class="rounded-circle img-fluid d-block mx-auto" src="http://placehold.it/200x200" alt="">
          <h3>
            <small>Jugador</small>
          </h3>
          <p></p>
        </div>
      </div>

    </div>