
@extends('layout.mainlayout')
<!DOCTYPE html>
<html>
<head>
	<title>
		{{ trans('nosotros.titleHistoria') }}
	</title>
	<!-- Bootstrap core CSS -->
    <link href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="{{asset('css/modern-business.css')}}" rel="stylesheet">
</head>
<body>

 <div class="container">

      <!-- Portfolio Item Heading -->
      <h1 class="my-5">{{ trans('nosotros.title') }}</h1>

      <!-- Portfolio Item Row -->
      <div class="row">

        <div class="col-md-4">
          <img src="img/KW_Logo.jpg" alt="" height="400">
        </div>

        <div class="col-md-8">
          <h3 class="my-3">KW eSports Club</h3>
          <p>
             {{ trans('nosotros.historia') }}
          <br/>
          <br/>
             {{ trans('nosotros.historia1') }}
			    <br/>
          <br/>
             {{ trans('nosotros.historia2') }}
			    <br/>
             {{ trans('nosotros.historia3') }}
		      </p>
        </div>

      </div>
      <!-- /.row -->
      

    </div>
	

</body>
</html>