@include('layout.partials.contact')
<!DOCTYPE html>
<html>
<head>

	@include('layout.partials.head')

	<title>
		{{ trans('contacto.contactoTitle') }}
	</title>
	<!-- Bootstrap core CSS -->
    <link href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="{{asset('css/modern-business.css')}}" rel="stylesheet">
</head>
<body>
	@include('layout.partials.nav')
 
 
	@yield('content')

	 
  <!--incluimos formulario-->
	@include('layout.partials.form')
	@include('layout.partials.footer-scripts')
	@include('layout.partials.footer-scripts-contact') 

</body>
</html>
