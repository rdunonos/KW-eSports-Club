<?php

return [

	'blogPartidos'=>'Blog of matches',
	'blogEventos'=>'Blog of events',

	'anterior'=>'Older',
	'siguiente'=>'Newer',

	'crear' => 'Create Post',
	'titulo' => 'Title',
	'body' => 'Content',
	'submit' => 'Publish',

	'volver'=>'Back',
	'seleccionar'=>'Select File',
	'modificacion'=>'Last modification',

	'editar'=>'Edit post',
	'edit'=>'Edit',

	'problem'=>'There were some problems with your input.',

];