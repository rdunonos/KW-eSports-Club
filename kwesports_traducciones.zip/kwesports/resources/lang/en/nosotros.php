<?php

return [

	'titleHistoria' => 'Club history',

	'title' => 'Our history',
    'historia' => 'Created in June 2017 by Helena "hakki", after finishing a project with a club in which she played as "support" of the game League of Legends, she decided on her own to try her luck creating her own team , including some of the players with whom he participated in other clubs, all without noticing what he would become and what lies ahead. ',
    'historia1'=> 'Helena "hakki" CEO of the KW team and coach of the KW League of Legends team, at 23 years of age, has achieved the 1st position in the second national division of the Spanish League of Legends (LEL) in its first participation in said league.',
    'historia2'=> 'Different players from different games came together to form the KW family. In addition to League of Legends (LOL), Playerunknowns Battlegrounds (PUBG), Hearstone (HS), Arena of Valor (AOV), this family continues to grow to further expand the range of eSport to which we belong.',
    'historia3'=> ' KW is not just a team like any other, we are a family of different worlds, but we all agree on one, the eSport. GO KW! ',
    
    'titleGaleria' => 'Gallery',
    'title2' => 'Photo gallery',
    
];