<?php
return [

    'inicio' => 'home',
    'nosotros'=> 'the club',
    'equipos'=> 'teams',
    'blog'=> 'blog',
    'contacto'=> 'contact',
    
    'historia'=> 'history',
    'galeria'=> 'gallery',
    'eventos'=>'events',
    'partidos'=>'matches',
    
];