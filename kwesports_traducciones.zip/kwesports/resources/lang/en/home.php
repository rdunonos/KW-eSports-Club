<?php

return [

	'twitter'=>'Follow us!',
	'mas'=>'Learn more',

	'nosotros'=>'About us',
	'nosotros2'=>'We are KW eSports Club, a project started by 0 by a player who said enough. Born of bad blood and sexist discrimination, we are prepared to fight ...',
	'evento'=>'Last event',
	'evento2'=>'We are going to Gamergy! <br> The League of Legends, Hearthstone and Arena of Valor teams are going to this great event located in Madrid. The 15 players that form these squads will reside in a rented house to feel more united than ever. Attentive to the photos and news from 22 to 25 of ...',
	'partido'=>'Last match',
	'partido2'=>'Last May 23, the League of Legends team faced the feared OKGG with an even conclusion, 1-1. After this draw in the last day of the Spanish League of Lol, our guys remain third of the first division. More luck in the next! #GOKW',

];