<?php

return [

	'competiciones'=>'Active competitions',
	'equipo'=>'Our team',

];