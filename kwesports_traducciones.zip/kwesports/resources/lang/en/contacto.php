<?php
return [

	'contactoTitle'=>'Contact',

    'title' => 'Contact with us',
    'nombre' => 'Name',
    'email' => 'Email',
    'mensaje' => 'Message',
    'enviar' => 'Submit',

    'validarNombre'=>'Empty name field',
    'validarEmail'=>'Valid email required: ex@abc.xyz',
    'validarMensaje'=>'Empty message field',

   
    
];