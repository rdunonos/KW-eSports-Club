<?php
return [

    'inicio' => 'inicio',
    'nosotros'=> 'nosotros',
    'equipos'=> 'equipos',
    'blog'=> 'blog',
    'contacto'=> 'contacto',

    'historia'=> 'historia',
    'galeria'=> 'galleria',
    'eventos'=>'eventos',
    'partidos'=>'partidos',
    
];