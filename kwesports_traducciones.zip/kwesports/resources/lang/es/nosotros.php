<?php

return [

	'titleHistoria' => 'Historia del club',
	'title' => 'Nuestra historia',
    'historia'=> 'Creado en Junio de 2017 por Helena "hakki", tras finalizar un proyecto con un club en el que ella jugaba como "support" del juego League of Legends, decidió por sus propios medios probar suerte creando su propio equipo, incluyendo algunos de los jugadores con los que participó en otros clubes, todo ello sin reparar en lo que llegaría a convertirse y en lo que le queda por delante.',
    'historia1'=> 'Helena "hakki" CEO del equipo KW y coach del equipo KW League of Legends, a sus 23 años de edad, ha logrado la 1ª posición en la segunda división nacional de la Liga Española de League of Legends (LEL) en su primera participación en dicha liga.',
    'historia2'=> 'Diferentes jugadores de distintos juegos nos unimos formando la familia de KW. Además de League of Legends (LOL), Playerunknowns Battlegrounds (PUBG), Hearstone (HS), Arena of Valor (AOV), esta familia sigue creciendo para ampliar aún más el abanico del eSport al que pertenecemos.',
    'historia3'=> ' KW no solo es un equipo como otro cualquiera, somos una familia de distintos mundos, pero que todos coincidimos en uno, los eSport. ¡GO KW!',
    

    'titleGaleria' => 'Galeria',
    'title2' => 'Galeria de fotos',

];