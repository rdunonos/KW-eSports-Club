<?php

return [

	'competiciones'=>'Competiciones activas',
	'equipo'=>'Nuestro equipo',


];