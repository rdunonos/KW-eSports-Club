<?php

return [

	'twitter'=>'Síguenos!',
	'mas'=>'Leer más',

	'nosotros'=>'Sobre Nosotros',
	'nosotros2'=>'Somos KW eSports Club, un proyecto empezado de 0 por una jugadora que dijo basta. Nacidos del mal rollo y la discriminación sexista, estamos preparados para luchar...',
	'evento'=>'Último evento',
	'evento2'=>'Nos vamos a Gamergy!<br>Los equipos de League of Legends, Hearthstone y Arena of Valor vamos a este gran evento situado en Madrid. Los 15 jugadores que forman estas squads residiremos en una casa alquilada para sentirnos más unidos que nunca. Atentos a las fotos y notícias del 22 al 25 de...',
	'partido'=>'Último partido',
	'partido2'=>'El último 23 de Mayo el equipo de League of Legends se enfrentó al temido OKGG con una conclusión igualada, 1-1. Después de este empate en la última jornada de la Liga Española de Lol, nuestros chicos quedan terceros de la primera divisón. Más suerte en la próxima! #GOKW',
    
];