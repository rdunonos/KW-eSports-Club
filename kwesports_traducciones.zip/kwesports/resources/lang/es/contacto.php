<?php
return [
	'contactoTitle'=>'Contacto',

    'title' => 'Contacta con nosotros',
    'nombre' => 'Nombre',
    'email' => 'Email',
    'mensaje' => 'Mensaje',
    'enviar' => 'Enviar',

    'validarNombre'=>'Campo Nombre vacío',
    'validarEmail'=>'Email válido requerido: ex@abc.xyz',
    'validarMensaje'=>'Campo mensaje vacío',

   
    
];