<?php

return [

	'blogPartidos'=>'Blog de Partidos',
	'blogEventos'=>'Blog de Eventos',


	'anterior'=>'Anterior',
	'siguiente'=>'Siguiente',

	'crear'=>'Crear Post',
	'titulo'=>'Título',
	'body'=>'Contenido',
	'submit'=>'Publicar',

	'volver'=>'Volver',
	'seleccionar'=>'Seleccionar Archivo',
	'modificacion'=>'Úlima modificación',

	'editar'=>'Editar post',
	'edit'=>'Editar',
	'problem'=>'Hubo algunos problemas con su entrada.',


];