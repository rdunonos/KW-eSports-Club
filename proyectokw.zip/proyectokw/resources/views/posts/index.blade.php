@extends('layouts.main')
@section('content')
<div class="container">
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <div class="blogs">
        <div class="text-center">
          <h2>Blog</h2>
          <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu<br>
          vestibulum volutpat libero sollicitudin vitae Curabitur ac aliquam <br>
          </p>
        </div>
        <hr>
      </div>
    </div>
  </div>
</div>

  <div class="popular-tags">
    <ul class="tags">
      <li><a href="{{route('posts.create')}}">Create new Post</a></li>
    </ul>
  </div>


<div class="container">
  <div class="row">
    <div class="col-md-8">
    @foreach($posts as $post)
      <div class="page-header">
        <div class="blog">
          <h5>February,22 2015</h5>
          <h5>Category : <strong>{{$post->category->name}}</strong></h5>
          <img src="{{asset('images/'.$post->image)}}" class="img-responsive"alt="">
          <h5>{{$post->title}}</h5>
          <p>{{substr(strip_tags($post->body),0,360) }}{{ strlen(strip_tags($post->body)) > 360 ? "..." : ""}}</p>
          <div class="card-body">
            <a href="{{route('posts.show',$post->id) }}" class="btn btn-primary"> Learn more &rarr;</a>
          </div>
        </div>
      </div>
     @endforeach

      <div class="container">
        <div class="row">
          <nav>
            <ul class="pagination">
            <li><a href="#"><span aria-hidden="true">&laquo;</span><span class="sr-only">Previous</span></a></li>
            <li><a href="#">1</a></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
            <li><a href="#">5</a></li>
            <li><a href="#"><span aria-hidden="true">&raquo;</span><span class="sr-only">Next</span></a></li>
            </ul>
          </nav>
        </div>
      </div>
    </div>




    <div class="col-md-4">
      <form class="form-search">
        <input class="form-control" type="text" placeholder="Search..">
      </form>
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>Popular Posts</strong>
        </div>
        <div class="panel-body">
          <div class="media">
            <a class="media-left" href="#">
              <img src="img/b.jpg" alt="">
            </a>
            <div class="media-body">
              <h4 class="media-heading">Kelly Hidayah</h4>
              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit,
              sed diam nonummy nibh euismod tincidunt ut laoreet dolore
              </p>
              <div class="ficon">
                <a href="#" alt="">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="panel-body">
          <div class="media">
            <a class="media-left" href="#">
              <img src="img/a.jpg" alt="">
            </a>
            <div class="media-body">
              <h4 class="media-heading">Kelly Hidayah</h4>
              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit,
              sed diam nonummy nibh euismod tincidunt ut laoreet dolore
              </p>
              <div class="ficon">
                <a href="#" alt="">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="panel-body">
          <div class="media">
            <a class="media-left" href="#">
              <img src="img/c.jpg" alt="">
            </a>
            <div class="media-body">
              <h4 class="media-heading">Kelly Hidayah</h4>
              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit,
              sed diam nonummy nibh euismod tincidunt ut laoreet dolore
              </p>
              <div class="ficon">
                <a href="#" alt="">Read more</a>
              </div>
            </div>
          </div>
        </div>
        <div class="panel-body">
          <div class="media">
            <a class="media-left" href="#">
              <img src="img/d.jpg" alt="">
            </a>
            <div class="media-body">
              <h4 class="media-heading">Kelly Hidayah</h4>
              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit,
              sed diam nonummy nibh euismod tincidunt ut laoreet dolore
              </p>
              <div class="ficon">
                <a href="#" alt="">Read more</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



@endsection
