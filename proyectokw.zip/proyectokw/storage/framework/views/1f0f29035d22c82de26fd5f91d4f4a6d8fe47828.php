<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </head>
  <body>
    <div class="header">
      <?php $__env->startSection('header'); ?>
      <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse.collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.html"><span>KW</span></a>
          </div>
          <div class="navbar-collapse collapse">
            <div class="menu">
              <ul class="nav nav-tabs" role="tablist">
                <li role="presentation"><a href="<?php echo e(asset('')); ?>">Home</a></li>
                <li role="presentation"><a href="services.html">Nosotros</a></li>
                <li role="presentation"><a href="<?php echo e(asset('posts')); ?>">Blog</a></li>
                <li role="presentation"><a href="portfolio.html">Portfolio</a></li>
                <li role="presentation"><a href="<?php echo e(asset('contact')); ?>">Contact</a></li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
      <?php echo $__env->yieldSection(); ?>
    </div>

    <div class="container">
      <?php echo $__env->yieldContent('content'); ?>
    </div>

    <div class="footer">
      <?php $__env->startSection('footer'); ?>
      <footer>


    		<div class="last-div">
    			<div class="container">
    				<div class="row">
    					<div class="copyright">
    						© 2014 eNno Multi-purpose theme | <a target="_blank" href="http://bootstraptaste.com">Bootstraptaste</a>
    					</div>
                        <!--
                            All links in the footer should remain intact.
                            Licenseing information is available at: http://bootstraptaste.com/license/
                            You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=eNno
                        -->
    				</div>
    			</div>
    			<div class="container">
    				<div class="row">
    					<ul class="social-network">
    						<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook fa-1x"></i></a></li>
    						<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter fa-1x"></i></a></li>
    						<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin fa-1x"></i></a></li>
    						<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest fa-1x"></i></a></li>
    						<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus fa-1x"></i></a></li>
    					</ul>
    				</div>
    			</div>

    			<a href="" class="scrollup"><i class="fa fa-chevron-up"></i></a>


    		</div>
    	</footer>
      <?php echo $__env->yieldSection(); ?>
    </div>
      <div class="js">
        <?php $__env->startSection('jsss'); ?>
        <script src="<?php echo e(asset('js/jquery-2.1.1.min.js')); ?>"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.easing.1.3.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.isotope.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.bxslider.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/fliplightbox.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/functions.js')); ?>"></script>
        <script type="text/javascript">$('.portfolio').flipLightBox()</script>
        <?php echo $__env->yieldSection(); ?>
      </div>
  </body>
</html>
