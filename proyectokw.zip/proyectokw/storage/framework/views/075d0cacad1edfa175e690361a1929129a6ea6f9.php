<h1>porba</h1>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($post); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
