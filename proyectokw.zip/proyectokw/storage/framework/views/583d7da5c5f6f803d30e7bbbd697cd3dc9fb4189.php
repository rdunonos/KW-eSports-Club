<h1>ash</h1>
<?php echo e($posts->body); ?>

