
  <div class="container">

      <!-- Introduction Row -->
      <h1 class="my-4">Hearthstone</h1>

      <h3 class="my-4">Competiciones
        <small>activas</small>
      </h3>
      <ul>
      <li>
      	<p>Liga Española de League of Legends</p>
      </li>
      <li>
      	<p>Rising League</p>
      </li>
      </ul>

      <!-- Team Members Row -->
      <div class="row">
        <div class="col-lg-12">
          <h2 class="my-4">Nuestro Equipo</h2>
        </div>
        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <img class="rounded-circle img-fluid d-block mx-auto" src="http://placehold.it/200x200" alt="">
          <h3>Exterminació
            <small>Jugador</small>
          </h3>
          <p>Capitán de nuestro equipo de Hearthstone! <a href="https://www.twitch.tv/byakuias">Twitch</a></p>
        </div>
        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <img class="rounded-circle img-fluid d-block mx-auto" src="http://placehold.it/200x200" alt="">
          <h3>John Smith
            <small>Job Title</small>
          </h3>
          <p>What does this team member to? Keep it short! This is also a great spot for social links!</p>
        </div>
        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <img class="rounded-circle img-fluid d-block mx-auto" src="http://placehold.it/200x200" alt="">
          <h3>John Smith
            <small>Job Title</small>
          </h3>
          <p>What does this team member to? Keep it short! This is also a great spot for social links!</p>
        </div>
      </div>

    </div>