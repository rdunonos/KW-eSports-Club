<!DOCTYPE html>
<html>
<head>
	<title>
		Arena of Valor
	</title>
	<!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/modern-business.css')); ?>" rel="stylesheet">
</head>
<body>

  <div class="container">

      <!-- Introduction Row -->
      <h1 class="my-4">Arena of Valor</h1>

      <h3 class="my-4">Competiciones
        <small>activas</small>
      </h3>
      <ul>
      <li>
      	<p></p>
      </li>
      <li>
      	<p></p>
      </li>
      </ul>

      <!-- Team Members Row -->
      <div class="row">
        <div class="col-lg-12">
          <h2 class="my-4">Nuestro Equipo</h2>
        </div>
        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <img class="rounded-circle img-fluid d-block mx-auto" src="http://placehold.it/200x200" alt="">
          <h3>
            <small>Jugador</small>
          </h3>
          <p></p>
        </div>
        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <img class="rounded-circle img-fluid d-block mx-auto" src="http://placehold.it/200x200" alt="">
          <h3>
            <small>Jugador</small>
          </h3>
          <p></p>
        </div>
        <div class="col-lg-4 col-sm-6 text-center mb-4">
          <img class="rounded-circle img-fluid d-block mx-auto" src="http://placehold.it/200x200" alt="">
          <h3>
            <small>Jugador</small>
          </h3>
          <p></p>
        </div>
      </div>

    </div>


</body>
</html>
<?php echo $__env->make('layout.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>