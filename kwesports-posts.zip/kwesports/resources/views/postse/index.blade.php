@extends('layout.mainlayout')

  <div class="container">
      <div class="row">
        <!-- Blog Entries Column -->
        <div class="col-md-8">

          <h1 class="my-4">Blog
            <small>de Eventos</small>
          </h1>
          <div class="pull-right">
            <a class="btn btn-success" href="{{ route('postse.create') }}"> Create New Post</a>
          </div>

          @if ($message = Session::get('success'))
                  <div class="alert alert-success">
                      <p>{{ $message }}</p>
                  </div>
              @endif
          <!-- Blog Post -->
          @foreach ($posts as $post )
          <div class="card mb-4">
            <img src="{{asset('images/'.$post->image)}}" height="400" width="700">
            <div class="card-body">
              <h3>{{$post->title}}</h3>
               <p>{{substr(strip_tags($post->body),0,250) }}{{ strlen(strip_tags($post->body)) > 250 ? "..." : ""}}</p>
              <a href="{{ route('postse.show',$post->id) }}" class="btn btn-primary"> Read More &rarr;</a>
            </div>
            <div class="card-footer text-muted">
              <h6><strong>Published:{{ date('M j, Y H:i',strtotime($post->created_at ))}}</strong></h6>
              <a href="#">Start Bootstrap</a>
            </div>
          </div>
          @endforeach
          <!-- Blog Post -->

          <!-- Pagination -->
          <ul class="pagination justify-content-center mb-4">
            <li class="page-item">
              <a class="page-link" href="#">&larr; Older</a>
            </li>
            <li class="page-item disabled">
              <a class="page-link" href="#">Newer &rarr;</a>
            </li>
          </ul>

        </div>

      </div>
      <!-- /.row -->

    </div>
