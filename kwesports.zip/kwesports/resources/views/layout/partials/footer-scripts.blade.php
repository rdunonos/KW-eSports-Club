
<!-- Bootstrap core JavaScript
 
================================================= -->
 
<!-- Placed at the end of the document so the pages load faster -->
 
 <script src="vendor/jquery/jquery.min.js"></script>
 <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
 
 
 
<!-- Bootstrap core JavaScript
 
================================================= -->
 
