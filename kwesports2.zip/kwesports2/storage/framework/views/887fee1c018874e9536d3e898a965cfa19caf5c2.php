
  <div class="contact1">
    <div class="container-contact1">
      <div class="contact1-pic js-tilt" data-tilt>
        <img src="img/img-01.png" alt="IMG">
      </div>

      <form action="<?php echo e(route('contacto.store')); ?>" class="contact1-form validate-form" onkeypress="" method="POST">
        <span class="contact1-form-title">
          Contacta con nosotros
        </span>

        <div class="wrap-input1 validate-input" data-validate = "Campo Nombre vacío" >
          <input class="input1" type="text" name="name" id="name" placeholder="Nombre">
          <span class="shadow-input1"></span>
        </div>

        <div class="wrap-input1 validate-input" data-validate = "Email válido requerido: ex@abc.xyz">
          <input class="input1" type="text" name="email" id="email" placeholder="Email">
          <span class="shadow-input1"></span>
        </div>


        <div class="wrap-input1 validate-input" data-validate = "Campo mensaje vacío">
          <textarea class="input1" name="comments" id="comments" placeholder="Mensaje"></textarea>
          <span class="shadow-input1"></span>
        </div>
        <div>
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        </div>
        <div class="container-contact1-form-btn">
          <button class="contact1-form-btn" name="submit" value="submit">
            <span>
              Enviar
              <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
            </span>
          </button>
        </div>
      </form>
    </div>
  </div>
  <script src="js/main.js"></script>
