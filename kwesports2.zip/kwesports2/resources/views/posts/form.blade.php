<head>
  <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
</head>

<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <h1>Crear Post</h1>
        <div class="form-group">
            <strong>Título:</strong>
            {{ Form::text('title', null, array('placeholder' => 'Title','class' => 'form-control')) }}
        </div>

        <div class="form-group">
            {{ Form::label('Image')}}
            {{ Form::file('image', null, array('placeholder' => 'Title','class' => 'form-control')) }}
        </div>

        <div class="form-group">
            <strong>Body:</strong>
            {{ Form::textarea('body', null, array('placeholder' => 'Body','class' => 'form-control','style'=>'height:150px')) }}
        </div>

    <div class="btn btn-success btn-lg btn-block">
            <button type="submit" class="btn btn-success">Submit</button>
    </div>
</div>
</div>
