
 		<br/><br/><br/><br/>
        <footer class="py-5 bg-dark">
      		<div class="container">
        		<p class="m-0 text-center text-white">Copyright &copy; KW eSports Club 2018</p>
      		</div>
      <!-- /.container -->
    	</footer>
 
   
  