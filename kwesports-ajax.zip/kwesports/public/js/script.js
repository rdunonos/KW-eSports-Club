$("#registro").click(function(){
	var dato = $("#contacto").val();
	var route = "/contacto";
	var token = $("#token").val();

	$.ajax({
		url: route,
		headers: {'X-CSRF-TOKEN': token},
		type: 'POST',
		dataType: 'json',
		data:{contacto: dato},

		success:function(){
			$("#msj-success").fadeIn();
		},
		error:function(msj){
			$("#msj").html(msj.responseJSON.contacto);
			$("#msj-error").fadeIn();
		}
	});
});