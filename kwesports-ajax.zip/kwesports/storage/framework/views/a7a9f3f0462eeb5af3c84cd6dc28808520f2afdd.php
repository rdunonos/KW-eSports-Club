	
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>KW eSports</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!--CSS personalizado

<link href="<?php echo e(asset('vendor/bootstrap/css/style.css')); ?>" rel="stylesheet">
    -->
    <link href="vendor/bootstrap/css/styles.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/modern-business.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Jockey+One" rel="stylesheet">
 
<!-- Bootstrap core CSS -->
 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUIyJ" crossorigin="anonymous">
 