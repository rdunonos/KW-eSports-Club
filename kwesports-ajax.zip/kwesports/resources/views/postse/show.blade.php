@extends('layout.mainlayout')

  <div class="container">
    <div class="row">
        <div class="col-md-8">
          <h1>{{ $post->title }}</h1>
            <img src="{{asset('images/'.$post->image)}}" height="400" width="700">
            <p class="lead">{!! $post->body !!}</p>
        </div>

        <div class="col-md-4">
            <div class="well">

              <dl class="dl-horizontal">
                <dt>Last Updated:</dt>
                <dd>{{date('M j, Y H:i',strtotime($post->updated_at))}}</dd>
              </dl>
              <hr>
              <div class="row">
                <div class="col-sm-6">
                    <a href="{{ route('postse.edit',$post->id) }}" class="btn btn-primary btn-block">edit</a>
                </div>
                <div class="col-sm-6">
                      {!! Form::open(['method' => 'DELETE','route' => ['postse.destroy', $post->id],'style'=>'display:inline']) !!}
                      {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
                      {!! Form::close() !!}
                </div>
              </div>
            </div>
          </div>
        </div>

            <div class="pull-left">
                <a class="btn btn-primary" href="{{ route('posts.index') }}"> Back</a>
            </div>
        </div>
    </div>
  </div>
