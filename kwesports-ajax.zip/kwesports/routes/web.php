<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/




Route::get('/', function () {
    return view('inicio');
});
/*->with(compact('pubg'));*/

Route::resource('/contacto', 'ContactoController');

Route::resource('/posts','PostController');
Route::resource('/postse','PostEController');


Route::get('inicio','IntentoController@inicio');



Route::get('galeria','IntentoController@galeria');
Route::get('historia','IntentoController@historia');


Route::get('calendario','IntentoController@calendario');

Route::get('lol','IntentoController@lol');


Route::get('aov','IntentoController@aov');


Route::get('hs','IntentoController@hs');


Route::get('pubg','IntentoController@pubg');



Route::get('contacto','IntentoController@contacto');

/*Route::get('/intento', 'IntentoController@index');
*/
