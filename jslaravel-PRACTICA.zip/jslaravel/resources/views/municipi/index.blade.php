@extends('layout')
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
              <h2>Info. Municipis</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{route('municipi.create')}}"> Create New Municipi</a>
            </div>
        </div>
    </div>


    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif


    <table class="table table-bordered">
        <tr>
            <th>Municipi Nom:</th>
            <th>ID Municipi</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($municipis as $municipi)
        <tr>
            <td>{{$municipi->nom_municipi}}</td>
            <td>{{$municipi->id}}</td>
            <td>
            {!! link_to_route('municipi.edit', $title = 'Edit', $parameters = $municipi->id, $attributes = ['class'=>'btn btn-primary']); !!}
            {!! Form::open(['method' => 'DELETE','route' => ['municipi.destroy', $municipi->id],'style'=>'display:inline']) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
            {!! Form::close() !!}
            </td>
        </tr>
        @endforeach()
    </table>
    <div class="pull-right">
        <a class="btn btn-success" href="/"> Volver</a>
    </div>
