@extends('layout')
@section('content')

{!! Form::open(['route'=>'municipi.store', 'method'=>'POST'])!!}
    @include('municipi.formulario')
{!! Form::submit('Add',['class'=>'btn btn-primary']) !!}
{!! Form::close() !!}

@endsection
