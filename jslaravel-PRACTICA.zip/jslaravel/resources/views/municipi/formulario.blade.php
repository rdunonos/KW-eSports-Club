<div class="form-group">
  {!! Form::label('ID')!!}
  {!! Form::number('ciutat_id',null,['class'=>'form-control','placeholder'=>'ID de la Ciutat'])!!}
</div>

<div class="form-group">
  {!! Form::label('Municipi')!!}
  {!! Form::text('nom_municipi',null,['class'=>'form-control','placeholder'=>'Nom Municipi'])!!}
</div>
