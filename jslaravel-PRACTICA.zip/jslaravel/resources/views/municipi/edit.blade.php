@extends('layout')
@section('content')

  {!! Form::model($municipi, ['method' => 'PUT','route' => ['municipi.update', $municipi->id]]) !!}
      @include('municipi.formulario')
   {!! Form::submit('Actualizar',['class'=>'btn btn-primary']) !!}
  {!! Form::close() !!}

@endsection
