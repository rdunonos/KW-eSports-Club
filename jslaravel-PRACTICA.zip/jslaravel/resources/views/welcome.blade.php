@extends('layout')
@section('content')
<center><h3>Practica Laravel One to Many
            Ciuttat | Municipis</h3></center>
<div class="pull-right">
    <a class="btn btn-info" href="{{route('ciutat.index')}}"> Ir a Ciutats</a>
</div>

<div class="pull-right">
    <a class="btn btn-info" href="{{route('municipi.index')}}"> Ir a Mmunicipis</a>
</div>

<table class="table table-bordered">
    <tr>
        <th>Ciutat</th>
        <th>ID:Ciutat</th>
        <th>Pais</th>
        <th>Municipi</th>
    </tr>
    @foreach ($ciutats as $ciutat)
      @foreach ($ciutat->municipi as $muni)
    <tr>
        <td>{{$ciutat->name}}</td>
        <td>{{$ciutat->id}}</td>
        <td>{{$ciutat->country}}</td>
        <td>{{$muni->nom_municipi}}</td>

    </tr>
    @endforeach
  @endforeach
</table>
