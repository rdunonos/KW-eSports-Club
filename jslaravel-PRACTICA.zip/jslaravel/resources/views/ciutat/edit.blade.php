@extends('layout')
@section('content')

  {!! Form::model($ciutat, ['method' => 'PUT','route' => ['ciutat.update', $ciutat->id]]) !!}
      @include('ciutat.formulario')
   {!! Form::submit('Actualizar',['class'=>'btn btn-primary']) !!}
  {!! Form::close() !!}

@endsection
