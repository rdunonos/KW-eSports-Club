@extends('layout')
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
              <h2>Info. Ciutats</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{route('ciutat.create')}}"> Create New Ciutat</a>
            </div>
        </div>
    </div>


    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif


    <table class="table table-bordered">
        <tr>
            <th>Ciutat</th>
            <th>Pais</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($ciutats as $ciutat)
        <tr>
            <td>{{$ciutat->name}}</td>
            <td>{{$ciutat->country}}</td>
            <td>
            {!! link_to_route('ciutat.edit', $title = 'Edit', $parameters = $ciutat->id, $attributes = ['class'=>'btn btn-primary']); !!}
            {!! Form::open(['method' => 'DELETE','route' => ['ciutat.destroy', $ciutat->id],'style'=>'display:inline']) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
            {!! Form::close() !!}
            </td>
        </tr>
        @endforeach()
    </table>
    <div class="pull-right">
        <a class="btn btn-success" href="/"> Volver</a>
    </div>
