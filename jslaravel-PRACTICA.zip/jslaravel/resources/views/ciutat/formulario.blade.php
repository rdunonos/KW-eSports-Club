<div class="form-group">
  {!! Form::label('Ciutat')!!}
  {!! Form::text('name',null,['class'=>'form-control','placeholder'=>'Nombre de la Ciutat'])!!}
</div>

<div class="form-group">
  {!! Form::label('Pais')!!}
  {!! Form::text('country',null,['class'=>'form-control','placeholder'=>'Pais'])!!}
</div>
