@extends('layout')
@section('content')

{!! Form::open(['route'=>'ciutat.store', 'method'=>'POST'])!!}
    @include('ciutat.formulario')
{!! Form::submit('Add',['class'=>'btn btn-primary']) !!}
{!! Form::close() !!}

@endsection
