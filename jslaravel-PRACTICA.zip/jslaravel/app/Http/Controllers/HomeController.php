<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ciutat;
class HomeController extends Controller
{
    public function index(){
      $ciutats = Ciutat::all();
      return view('welcome',compact('ciutats'));
    }
}
