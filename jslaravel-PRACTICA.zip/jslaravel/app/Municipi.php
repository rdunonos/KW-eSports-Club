<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Municipi extends Model
{
    protected $fillable = [
      'ciutat_id',
      'nom_municipi'
    ];

    public function ciutat(){
      return $this->belongsTo('App\Ciutat');
    }

}
