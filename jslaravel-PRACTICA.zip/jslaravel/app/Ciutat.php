<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ciutat extends Model
{
    protected $fillable =[
      'name',
      'country',
    ];

    public function municipi(){
      return $this->hasMany('App\Municipi');
    }
}
