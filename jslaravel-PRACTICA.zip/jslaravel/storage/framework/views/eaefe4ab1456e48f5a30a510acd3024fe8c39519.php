<div class="form-group">
  <?php echo Form::label('Ciutat'); ?>

  <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Nombre de la Ciutat']); ?>

</div>

<div class="form-group">
  <?php echo Form::label('Pais'); ?>

  <?php echo Form::text('country',null,['class'=>'form-control','placeholder'=>'Pais']); ?>

</div>
