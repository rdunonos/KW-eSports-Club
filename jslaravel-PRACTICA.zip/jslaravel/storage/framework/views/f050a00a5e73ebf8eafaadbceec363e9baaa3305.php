<?php $__env->startSection('content'); ?>
<center><h3>Practica Laravel One to Many
            Ciuttat | Municipis</h3></center>
<div class="pull-right">
    <a class="btn btn-info" href="<?php echo e(route('ciutat.index')); ?>"> Ir a Ciutats</a>
</div>

<div class="pull-right">
    <a class="btn btn-info" href="<?php echo e(route('municipi.index')); ?>"> Ir a Mmunicipis</a>
</div>

<table class="table table-bordered">
    <tr>
        <th>Ciutat</th>
        <th>ID:Ciutat</th>
        <th>Pais</th>
        <th>Municipi</th>
    </tr>
    <?php $__currentLoopData = $ciutats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciutat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $__currentLoopData = $ciutat->municipi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($ciutat->name); ?></td>
        <td><?php echo e($ciutat->id); ?></td>
        <td><?php echo e($ciutat->country); ?></td>
        <td><?php echo e($muni->nom_municipi); ?></td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>