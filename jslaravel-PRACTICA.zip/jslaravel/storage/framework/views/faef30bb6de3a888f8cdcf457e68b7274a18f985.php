<div class="form-group">
  <?php echo Form::label('ID'); ?>

  <?php echo Form::number('ciutat_id',null,['class'=>'form-control','placeholder'=>'ID de la Ciutat']); ?>

</div>

<div class="form-group">
  <?php echo Form::label('Municipi'); ?>

  <?php echo Form::text('nom_municipi',null,['class'=>'form-control','placeholder'=>'Nom Municipi']); ?>

</div>
