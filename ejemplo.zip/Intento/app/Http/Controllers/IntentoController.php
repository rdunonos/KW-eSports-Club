<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IntentoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function intento()
    {
        return view('intento');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function historia()
    {
        return view('historia');
    }

     public function galeria()
    {
        return view('galeria');
    }

    public function calendario()
    {
        return view('calendario');
    }

    public function equipos()
    {
        return view('equipos');
    }

    public function eventos()
    {
        return view('eventos');
    }
    public function partidos()
    {
        return view('partidos');
    }

    public function lol()
    {
        return view('lol');
    }

    public function aov()
    {
        return view('aov');
    }

    public function hs()
    {
        return view('hs');
    }

    public function pubg()
    {
        return view('pubg');
    }

    public function blog()
    {
        return view('blog');
    }


    public function contacto()
    {
        return view('contacto');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
